# Audit-chain signing material reads and rotation writes.
path "secret/data/musematic/+/audit-chain/*" {
  capabilities = ["read", "list", "update"]
}

path "secret/metadata/musematic/+/audit-chain/*" {
  capabilities = ["read", "list", "update"]
}

path "transit/sign/audit-chain" {
  capabilities = ["update"]
}
