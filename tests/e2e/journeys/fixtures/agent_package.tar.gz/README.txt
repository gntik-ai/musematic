fixture package payload
